class GroupLimitError(Exception):
    def __init__(self, message="Group can contain only 10 students"):
        super().__init__(message)